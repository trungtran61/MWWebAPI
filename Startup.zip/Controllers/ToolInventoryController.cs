﻿using MWWebAPI.Models;
//using MWWebAPI.Repository;
using System.Collections.Generic;
using System.Web.Http;
using MWWebAPI.DBRepository;
using System.Web;
using System.Linq;
using System;
using System.IO;
using System.Configuration;
using System.Net.Http;
using System.Net;

namespace MWWebAPI.Controllers
{
    //[Authorize]
    [RoutePrefix("api")]
    public class ToolInventoryController : ApiController
    {
        private static string imageLibrary = ConfigurationManager.AppSettings["imageLibrary"];
        private static string imageUrl = ConfigurationManager.AppSettings["imageUrl"];
        DBToolInventoryRepository ToolInventoryRepo = new DBToolInventoryRepository();
       
        [Route("SearchToolSetups")]
        [HttpPost]
        public HttpResponseMessage SearchToolSetups(ToolSetupSearchRequest toolSetupSearchRequest)
        {
            List<ToolSetupSearchResult> retSearchResult = ToolInventoryRepo.SearchToolSetups(toolSetupSearchRequest.SearchTerm);
            return Request.CreateResponse(HttpStatusCode.OK, retSearchResult);
        }

        [Route("lookup")]
        [HttpGet]
        public HttpResponseMessage GetByCategory([FromUri]LookUpRequest lookUpRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetLookupByCategory(lookUpRequest.Category, lookUpRequest.SearchTerm));
        }

        [Route("GetToolCategoryNames")]       
        public HttpResponseMessage GetToolCategoryNames()
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetToolCategoryNames());
        }

        [Route("GetCuttingMethodsWithTemplate")]
        [HttpGet]
        public HttpResponseMessage GetCuttingMethodsWithTemplate([FromUri]ToolSetupSearchRequest toolSetupSearchRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetCuttingMethodsWithTemplate(toolSetupSearchRequest.SearchTerm));
        }

        [Route("cuttingmethodtemplate/update")]
        [HttpPost]
        public HttpResponseMessage UpdateCuttingMethodTemplate(CuttingMethodTemplate cuttingMethodTemplate)
        {
            DBResponse dbResponse = ToolInventoryRepo.UpdateCuttingMethodTemplate(cuttingMethodTemplate);
            return Request.CreateResponse(HttpStatusCode.OK, new APIResponse
            {
                ResponseCode = 0,
                ResponseText = "Template updated"
            });
        }

        [Route("getCuttingMethodtemplate/{cuttingMethod}")]       
        public HttpResponseMessage GetTemplate(string cuttingMethod)
        {
            // URL can't handle period so use | instead
            cuttingMethod = cuttingMethod.Replace('|', '.');
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetCuttingMethodTemplate(cuttingMethod));
        }

        [Route("getToolSetupSheet/{id}")]
        public ToolSetupSheet GetToolSetupSheet(int id)
        {
            return ToolInventoryRepo.GetToolSetupSheet(id);
        }

        [Route("ToolSetupSheet/Update")]
        [HttpPost]
        public HttpResponseMessage UpdateToolSetupSheet(ToolSetupSheet toolSetupSheet)
        {
            DBResponse dbResponse = ToolInventoryRepo.UpdateToolSetupSheet(toolSetupSheet);
            return Request.CreateResponse(HttpStatusCode.OK, new APIResponse
            {
                ResponseCode = 0,
                ResponseText = "Setup Sheet updated"
            });
        }

        [Route("AddToolSetupToSetupSheet")]
        [HttpPost]
        public HttpResponseMessage AddToolSetupToSetupSheet(AddToolSetupRequest addToolSetupRequest)
        {
            DBResponse dbResponse = ToolInventoryRepo.AddToolSetupToSetupSheet(addToolSetupRequest);
            return Request.CreateResponse(HttpStatusCode.OK, new APIResponse
            {
                ResponseCode = 0,
                ResponseText = "Setup Sheet updated"
            });
        }

        [Route("DeleteConversionRule")]
        [HttpPost]
        public HttpResponseMessage DeleteConversionRule(ConversionRule conversionRule)
        {

            DBResponse dbResponse = ToolInventoryRepo.DeleteConversionRule(conversionRule);
            return Request.CreateResponse(HttpStatusCode.OK, new APIResponse
            {
                ResponseCode = 0,
                ResponseText = "Setup Sheet updated"
            });
        }

        [Route("DeleteToolSetup")]
        [HttpPost]
        public HttpResponseMessage DeleteToolSetup(DeleteToolSetupRequest deleteToolSetupRequest)
        {

            DBResponse dbResponse = ToolInventoryRepo.DeleteToolSetup(deleteToolSetupRequest);
            return Request.CreateResponse(HttpStatusCode.OK, new APIResponse
            {
                ResponseCode = 0,
                ResponseText = "Setup Sheet updated"
            });
        }

        [Route("SaveToolSetupGroup")]
        [HttpPost]
        public HttpResponseMessage SaveToolSetupGroup(ToolSetupGroupRequest toolSetupGroupRequest)
        {

            DBResponse dbResponse = ToolInventoryRepo.SaveToolSetupGroup(toolSetupGroupRequest);
            return Request.CreateResponse(HttpStatusCode.OK, new APIResponse
            {
                ResponseCode = 0,
                ResponseText = "Tool Setup Group updated"
            });
        }

        [Route("SaveConvertedProgram")]
        [HttpPost]
        public HttpResponseMessage SaveConvertedProgram(ProgramSaveRequest convertProgramSaveRequest)
        {

            int newSetupSheetID = ToolInventoryRepo.SaveConvertedProgram(convertProgramSaveRequest);
            return Request.CreateResponse(HttpStatusCode.OK, newSetupSheetID);            
        }

        [Route("UploadProvenProgram")]
        [HttpPost]
        public HttpResponseMessage UploadProvenProgram(UploadProgramRequest uploadProgramRequest)
        {

            int newSetupSheetID = ToolInventoryRepo.UploadProvenProgram(uploadProgramRequest);
            return Request.CreateResponse(HttpStatusCode.OK, newSetupSheetID);
        }

        [Route("SaveProgram")]
        [HttpPost]
        public HttpResponseMessage SaveProgram(ProgramSaveRequest convertProgramSaveRequest)
        {
            ToolInventoryRepo.SaveProgram(convertProgramSaveRequest);
            return Request.CreateResponse(HttpStatusCode.OK, 0);          
        }

        [Route("GetSearchResults/{category}/{term?}")]
        public HttpResponseMessage GetSearchResults(string category, string term = "")
        {
            List<string> retResults = ToolInventoryRepo.GetSearchResults(term, category);

            var resultList = retResults.Where(x => x.IndexOf(term, StringComparison.OrdinalIgnoreCase) > -1);
            return Request.CreateResponse(HttpStatusCode.OK, resultList.ToArray());
        }

        [Route("GetMachines/{prefix?}")]
        public HttpResponseMessage GetMachines(string prefix = "")
        {
            List<string> retPartNumbers = ToolInventoryRepo.GetMachines(prefix);
            return Request.CreateResponse(HttpStatusCode.OK, retPartNumbers.ToArray());
        }

        [Route("GetLookUpCategories/{searchTerm?}")]
        public HttpResponseMessage GetLookUpCategories(string searchTerm = "")
        {
            List<string> getCategories = ToolInventoryRepo.GetLookUpCategories(searchTerm);
            return Request.CreateResponse(HttpStatusCode.OK, getCategories.ToArray());
        }

        [Route("GetSSPPartNumbers/{partId?}")]
        public HttpResponseMessage GetSSPPartNumbers(string partId = "")
        {
            List<string> retPartNumbers = ToolInventoryRepo.GetSSPPartNumbers(partId);
            var resultList = retPartNumbers.Where(x => x.IndexOf(partId, StringComparison.OrdinalIgnoreCase) > -1);
            return Request.CreateResponse(HttpStatusCode.OK, resultList.ToArray());
        }

        [Route("GetMaterialSize/{materialType}/{term}")]
        public HttpResponseMessage GetSSPPartNumbers(string materialType, string term)
        {
            List<string> retMaterialSize = ToolInventoryRepo.GetMaterialSize(term, materialType);
            var resultList = retMaterialSize.Where(x => x.IndexOf(term, StringComparison.OrdinalIgnoreCase) > -1);
            return Request.CreateResponse(HttpStatusCode.OK, resultList.ToArray());
        }

        [Route("GetSSPOperations/{partId}/{operation?}")]
        public HttpResponseMessage GetSSPOperations(string partId, string operation = "")
        {
            List<string> retOperations = ToolInventoryRepo.GetSSPOperations(operation, partId);
            var resultList = retOperations.Where(x => x.IndexOf(operation, StringComparison.OrdinalIgnoreCase) > -1);
            return Request.CreateResponse(HttpStatusCode.OK, resultList.ToArray());
        }

        [Route("GetCuttingMethodTemplate/{cuttingMethod}/{n}")]
        public HttpResponseMessage GetCuttingMethodTemplate(string cuttingMethod, string n)
        {
            List<string> retTemplate = ToolInventoryRepo.GetCuttingMethodTemplate(cuttingMethod, n);
            return Request.CreateResponse(HttpStatusCode.OK, retTemplate.ToArray());
        }

        [Route("GetSetupSheets/{partNumber}/{revision}/{operation?}")]
        public HttpResponseMessage GetSetupSheets(string partnumber, string revision, string operation = "")
        {
            List<ToolSetupSheetHeader> setupSheetHeaders = ToolInventoryRepo.GetSetupSheets(partnumber, revision, operation);
            return Request.CreateResponse(HttpStatusCode.OK, setupSheetHeaders);
        }

        [Route("ConvertProgram")]
        [HttpPost]
        public HttpResponseMessage ConvertProgram(ConvertProgramRequest convertProgramRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.ConvertProgram(convertProgramRequest));
        }

        [Route("UploadProgram")]
        [HttpPost]
        public HttpResponseMessage UploadProgram()
        {
            if (HttpContext.Current.Request.Files.AllKeys.Any())
            {
                var httpPostedFile = HttpContext.Current.Request.Files["UploadedImage"];

                if (httpPostedFile != null)
                {
                    var fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath("~/ProvenPrograms"), httpPostedFile.FileName);
                    httpPostedFile.SaveAs(fileSavePath);
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "");
        }

        [Route("GetToolInventoryColumns")]
        public HttpResponseMessage GetToolInventoryColumns(string code)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetToolInventoryColumns());
        }

        [Route("GetToolInventoryColumns/{code}")]
        public HttpResponseMessage GetToolInventoryColumnsByCode(string code)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetToolInventoryColumnsByCode(code));
           
        }

        [Route("SaveToolInventoryCodeColumns")]
        [HttpPost]
        public HttpResponseMessage SaveToolInventoryCodeColumns(SaveCodeColumnsRequest saveCodeColumnsRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.SaveToolInventoryCodeColumns(saveCodeColumnsRequest));
        }

        [Route("CopyToolInventoryCodeColumns")]
        [HttpPost]
        public HttpResponseMessage CopyToolInventoryCodeColumns(CopyCodeColumnsRequest copyCodeColumnsRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.CopyToolInventoryCodeColumns(copyCodeColumnsRequest));
        }

        [Route("GetSelectedToolInventoryColumns/{codes?}")]
        public HttpResponseMessage GetSelectedToolInventoryColumns(string codes = "")
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetSelectedToolInventoryColumns(codes));
        }

        [Route("GetToolNames")]
        [HttpGet]
        public HttpResponseMessage GetToolNames([FromUri] LookUpRequest lookUpRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetToolNames(lookUpRequest.SearchTerm));
        }

        [Route("GetSearchableToolInventoryColumns/{codes?}")]
        public HttpResponseMessage GetSearchableToolInventoryColumns(string codes = "")
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetSelectedToolInventoryColumns(codes, true));
        }

        [Route("GetToolDetails/{ToolID}")]
        public HttpResponseMessage GetToolDetails(int ToolID)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.GetToolDetails(ToolID));
        }

        [Route("CopyTool")]
        [HttpPost]
        public HttpResponseMessage CopyTool(ToolInventorySaveRequest copyToolRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.CopyTool(copyToolRequest.ID));
        }

        [Route("CreateTool")]
        [HttpPost]
        public HttpResponseMessage CreateTool(ToolInventorySaveRequest toolInventorySaveRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.CreateTool(toolInventorySaveRequest));
        }


        [Route("DeleteTool")]
        [HttpPost]
        public HttpResponseMessage DeleteTool(ToolInventorySaveRequest toolInventorySaveRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ToolInventoryRepo.DeleteTool(toolInventorySaveRequest.ID));
        }

        [Route("SaveToolDetails")]
        [HttpPost]
        public HttpResponseMessage SaveToolDetails(ToolInventorySaveRequest toolInventorySaveRequest)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.SaveToolDetails(toolInventorySaveRequest));
        }
        //

        [Route("UpdateToolVendor")]
        [HttpPost]
        public HttpResponseMessage UpdateToolVendor(ToolInventorySearchResult toolInventorySearchResult)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.UpdateToolVendor(toolInventorySearchResult));
        }

        [Route("ToolInventorySearch")]
        [HttpPost]
        public HttpResponseMessage ToolInventorySearch(ToolInventorySearch toolInventorySearch)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.ToolInventorySearch(toolInventorySearch));
        }
        
        [Route("GetLookUpCategory")]
        [HttpPost]
        public HttpResponseMessage GetLookUpCategory(LookupCategorySearch lookupCategorySearch)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.GetLookUpCategory(lookupCategorySearch));
        }

        [Route("GetToolCuttingMethods/{ToolID}/{AllMethods}")]
        public HttpResponseMessage GetToolCuttingMethods(int ToolID, bool allMethods = true)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.GetToolCuttingMethods(ToolID, allMethods));
        }

        [Route("GetVendors/{categoryID?}/{searchTerm?}")]
        public HttpResponseMessage GetVendors(string searchTerm = "", int categoryID = 0)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.GetVendors(searchTerm, categoryID));
        }

        [Route("GetVendorInfo/{ID}")]
        public HttpResponseMessage GetVendorInfo(int ID)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.GetVendorInfo(ID));
        }
        //public LookupCategories GetLookUpCategory(LookupCategorySearch lookupCategorySearch)

        [Route("ToolInventorySearchSelected")]
        [HttpPost]
        public HttpResponseMessage ToolInventorySearchSelected(ToolInventorySearch toolInventorySearch)
        {
            return Request.CreateResponse(HttpStatusCode.OK,ToolInventoryRepo.ToolInventorySearchSelected(toolInventorySearch));
        }

        [Route("LinkTool")]
        [HttpPost]
        public HttpResponseMessage LinkTool(LinkToolRequest linkToolRequest)
        {
            DBResponse dbResponse = ToolInventoryRepo.LinkTool(linkToolRequest);
            return Request.CreateResponse(HttpStatusCode.OK,new APIResponse
            {
                ResponseCode = 0,
                ResponseText = linkToolRequest.Action + " successful."
            });
        }

        [Route("CheckOutCheckIn")]
        [HttpPost]
        public HttpResponseMessage CheckOutCheckIn(CheckOutCheckInRequest checkOutCheckInRequest)
        {
            DBResponse dbResponse = ToolInventoryRepo.CheckOutCheckIn(checkOutCheckInRequest);
            return Request.CreateResponse(HttpStatusCode.OK,new APIResponse
            {
                ResponseCode = 0,
                ResponseText = checkOutCheckInRequest.Action + " successful."
            });
        }

        [Route("SaveLookupCategory")]
        [HttpPost]
        public HttpResponseMessage SaveLookupCategory(SaveLookupCategoryRequest saveLookupCategoryRequest)
        {
            DBResponse dbResponse = ToolInventoryRepo.SaveLookupCategory(saveLookupCategoryRequest);
            return Request.CreateResponse(HttpStatusCode.OK,new APIResponse
            {
                ResponseCode = 0,
                ResponseText = "Save LookupCategory successful."
            });
        }
        [Route("UploadToolImage")]
        [HttpPost]
        public HttpResponseMessage UploadToolImage()
        {
            if (HttpContext.Current.Request.Files.AllKeys.Any())
            {
                // Get the uploaded image from the Files collection
                var httpPostedFile = HttpContext.Current.Request.Files["UploadedImage"];

                if (httpPostedFile != null)
                {
                    int toolID = Convert.ToInt32(HttpContext.Current.Request["ToolID"]);
                    string fileFormat = httpPostedFile.FileName.Substring(httpPostedFile.FileName.LastIndexOf('.')+1);
                    string fileName = string.Format("{0}.{1}", toolID, fileFormat);
                    var fileSavePath = 
                        string.Format("{0}\\ToolInventory\\{1}.{2}", imageLibrary+"", toolID, fileFormat);

                    httpPostedFile.SaveAs(fileSavePath);
                    ToolInventoryRepo.SaveToolImageInfo(toolID, fileName);
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "");
        }
    } 
}
