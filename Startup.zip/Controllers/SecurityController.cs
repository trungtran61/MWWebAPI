﻿using MWWebAPI.DBRepository;
using MWWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace MWWebAPI.Controllers
{
    [RoutePrefix("api/security")]
    public class SecurityController : ApiController
    {
        DBSecurityRespository securityInventoryRepo = new DBSecurityRespository();

        [Route("GetUsers")]
        [HttpGet]
        public HttpResponseMessage GetUsers([FromUri]SecurityModels.GetListRequest getUsersRequest)
        {
            SecurityModels.GetUsersResponse getUserResponse = securityInventoryRepo.GetUsers(getUsersRequest);
            return Request.CreateResponse(HttpStatusCode.OK, getUserResponse);
        }

        [Route("GetUser")]
        [HttpGet]
        public HttpResponseMessage GetUser(int id)
        {
            SecurityModels.User user = securityInventoryRepo.GetUser(id);
            return Request.CreateResponse(HttpStatusCode.OK, user);
        }

        [Route("GetRoles")]
        [HttpGet]
        public HttpResponseMessage GetRoles([FromUri]SecurityModels.GetListRequest getRolesRequest)
        {
            SecurityModels.GetRolesResponse getRolesResponse = securityInventoryRepo.GetRoles(getRolesRequest);
            return Request.CreateResponse(HttpStatusCode.OK, getRolesResponse);
        }

        [Route("GetRole")]
        [HttpGet]
        public HttpResponseMessage GetRole(int id)
        {
            SecurityModels.Role role = securityInventoryRepo.GetRole(id);
            return Request.CreateResponse(HttpStatusCode.OK, role);
        }

        [Route("GetPermission")]
        [HttpGet]
        public HttpResponseMessage GetPermission(int id)
        {
            SecurityModels.Permission permission = securityInventoryRepo.GetPermission(id);
            return Request.CreateResponse(HttpStatusCode.OK, permission);
        }

        [Route("GetPermissions")]
        [HttpGet]
        public HttpResponseMessage GetPermissions([FromUri]SecurityModels.GetListRequest getPermissionsRequest)
        {
            SecurityModels.GetPermissionsResponse getPermissionsResponse = securityInventoryRepo.GetPermissions(getPermissionsRequest);
            return Request.CreateResponse(HttpStatusCode.OK, getPermissionsResponse);
        }

        [Route("UpdateUserRoles")]
        [HttpPost]
        public HttpResponseMessage UpdateUserRoles(SecurityModels.UpdateUserRolesRequest updateUserRolesRequest)
        {
            securityInventoryRepo.UpdateUserRoles(updateUserRolesRequest);
            return Request.CreateResponse(HttpStatusCode.OK, "");
        }

        [Route("UpdateUserStatus")]
        [HttpPost]
        public HttpResponseMessage UpdateUserStatus(SecurityModels.UpdateUserStatusRequest updateUserStatusRequest)
        {
            securityInventoryRepo.UpdateUserStatus(updateUserStatusRequest);
            return Request.CreateResponse(HttpStatusCode.OK, "");
        }

        [Route("UpdateUserProfile")]
        [HttpPost]
        public HttpResponseMessage UpdateUserProfile(SecurityModels.User user)
        {
            user.Id = securityInventoryRepo.UpdateUserProfile(user);
            return Request.CreateResponse(HttpStatusCode.OK, user.Id);
        }

        [Route("UpdateRole")]
        [HttpPost]
        public HttpResponseMessage UpdateRole(SecurityModels.Role role)
        {
            try
            {
                role.Id = securityInventoryRepo.UpdateRole(role);
                return Request.CreateResponse(HttpStatusCode.OK, role.Id);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [Route("UpdateRoleStatus")]
        [HttpPost]
        public HttpResponseMessage UpdateRoleStatus(SecurityModels.Role permission)
        {
            securityInventoryRepo.UpdateRoleStatus(permission);
            return Request.CreateResponse(HttpStatusCode.OK, permission);
        }

        [Route("UpdatePermission")]
        [HttpPost]
        public HttpResponseMessage UpdatePermission(SecurityModels.Permission permission)
        {
            permission.Id = securityInventoryRepo.UpdatePermission(permission);
            return Request.CreateResponse(HttpStatusCode.OK, permission.Id);
        }

        [Route("UpdatePermissionStatus")]
        [HttpPost]
        public HttpResponseMessage UpdatePermissionStatus(SecurityModels.Permission permission)
        {
            securityInventoryRepo.UpdatePermissionStatus(permission);
            return Request.CreateResponse(HttpStatusCode.OK, permission);
        }

        [HttpPost]
        public HttpResponseMessage ValidateUser(SecurityModels.UserAuthRequest userAuthRequest)
        {
            SecurityModels.UserAuth userAuth = new SecurityModels.UserAuth();
            userAuth = securityInventoryRepo.ValidateUser(userAuthRequest);

            if (userAuth.IsAuthenticated)
                return Request.CreateResponse(HttpStatusCode.OK, userAuth);
            else
                return Request.CreateResponse(HttpStatusCode.NotFound, "Invalid Username/Password.");

        }
    }
}