﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MWWebAPI.Models
{
    public class SecurityModels
    {
        public class UserAuthRequest
        {           
            public string UserName { get; set; }
            public string Password { get; set; }            
        }

        public class UserAuth
        {
            public UserAuth() : base()
            {
                UserName = "Not Authorized";
                BearerToken = string.Empty;            
            }
            public string UserName { get; set; }
            public string BearerToken { get; set; }
            public bool IsAuthenticated {get; set;}
            public List<string> Permissions { get; set; }
        }

        public class User
        {            
            public int Id { get; set; }
            public string UserName { get; set; }
            public string BearerToken { get; set; }
            public string Password { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string DateCreated { get; set; }
            public bool Active { get; set; }
            public List<UserRole> Roles { get; set; }
            public string Permissions { get; set; }
        }

        public class UserRole
        {
            public string Name { get; set; }
            public bool Assigned { get; set; }
        }

        public class Role
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string DisplayName { get; set; }
            public bool Active { get; set; }
            public List<RolePermission> Permissions { get; set; }
        }

        public class RolePermission
        {
            public string Name { get; set; }
            public bool Assigned { get; set; }
        }

        public class Permission
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string DisplayName { get; set; }
            public bool Active { get; set; }
        }

        public class GetListRequest
        {
            public string SearchParm { get; set; } = "";
            public string SortColumn { get; set; }
            public string SortDirection { get; set; }
            public int ActiveOnly { get; set; }
            public int PageSize { get; set; } = 25;
            public int PageNumber { get; set; } = 1;
        }

        public class GetUsersResponse
        {
            public int RecordCount { get; set; }
            public List<User> Users { get; set; }
        }

        public class GetRolesResponse
        {
            public int RecordCount { get; set; }
            public List<Role> Roles { get; set; }
        }

        public class GetPermissionsResponse
        {
            public int RecordCount { get; set; }
            public List<Permission> Permissions { get; set; }
        }

        public class UpdateUserRolesRequest
        {
            public int ID { get; set; }
            public string Roles { get; set; }
        }

        public class UpdateUserStatusRequest
        {
            public int ID { get; set; }
            public bool Active { get; set; }
        }
    }
}