﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using MWWebAPI.Models;
using static MWWebAPI.Models.SecurityModels;

namespace MWWebAPI.DBRepository
{
    public class DBSecurityRespository : DBRepositoryBase, IDisposable
    {
        public UserAuth ValidateUser(UserAuthRequest userAuthRequest)
        {
            UserAuth userAuth = new UserAuth();

            using (SqlConnection con = new SqlConnection(SecurityConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("ValidateUser", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@UserName", SqlDbType.VarChar,20).Value = userAuthRequest.UserName;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 20).Value = userAuthRequest.Password;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        userAuth.UserName = reader["UserName"].ToString();
                        userAuth.Permissions = reader["Permissions"].ToString().Split(',').ToList();
                        userAuth.IsAuthenticated = true;
                    }
                }
                con.Close();
            }
            return userAuth;
        }

        public SecurityModels.GetUsersResponse GetUsers(SecurityModels.GetListRequest getUsersRequest)
        {
            SecurityModels.GetUsersResponse getUsersResponse = new SecurityModels.GetUsersResponse();
            List<SecurityModels.User> Users = new List<SecurityModels.User>();

            using (SqlConnection con = new SqlConnection(SecurityConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetUsers", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@SearchParm", SqlDbType.VarChar, 30).Value = getUsersRequest.SearchParm;
                    cmd.Parameters.Add("@PageSize", SqlDbType.Int, 0).Value = getUsersRequest.PageSize;
                    cmd.Parameters.Add("@PageNumber", SqlDbType.Int, 0).Value = getUsersRequest.PageNumber;

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    int recordNumber = 1;

                    while (reader.Read())
                    {
                        if (recordNumber == 1)
                            getUsersResponse.RecordCount = Convert.ToInt32(reader["RecordCount"].ToString());

                        Users.Add(new SecurityModels.User
                        {
                            Id = Convert.ToInt32(reader["ID"].ToString()),
                            UserName = reader["UserName"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Email = reader["Email"].ToString(),
                            Active = Convert.ToBoolean(reader["Active"].ToString())
                        });
                    }
                    getUsersResponse.Users = Users;
                }
                con.Close();
            }
            return getUsersResponse;
        }

        public SecurityModels.User GetUser(int id)
        {
            SecurityModels.User user = new SecurityModels.User();

            using (SqlConnection con = new SqlConnection(SecurityConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetUser", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        user.Id = Convert.ToInt32(reader["ID"].ToString());
                        user.UserName = reader["UserName"].ToString();
                        user.Password = reader["Password"].ToString();
                        user.FirstName = reader["FirstName"].ToString();
                        user.LastName = reader["LastName"].ToString();
                        user.Email = reader["Email"].ToString();
                        user.Active = id==0? false: Convert.ToBoolean(reader["Active"].ToString());
                        user.Roles = GetUserRoles(reader["Roles"].ToString());
                        user.Permissions = reader["Permissions"].ToString();
                    }
                }
                con.Close();
            }
            return user;
        }

        public SecurityModels.Role GetRole(int id)
        {
            SecurityModels.Role role = new SecurityModels.Role();

            using (SqlConnection con = new SqlConnection(SecurityConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetRole", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        role.Id = Convert.ToInt32(reader["ID"].ToString());
                        role.Name = reader["Name"].ToString();
                        role.DisplayName = reader["DisplayName"].ToString();
                        role.Active = id == 0 ? false : Convert.ToBoolean(reader["Active"].ToString());
                        role.Permissions = GetRolePermissions(reader["Permissions"].ToString());
                        
                    }
                }
                con.Close();
            }
            return role;
        }

        public SecurityModels.Permission GetPermission(int id)
        {
            SecurityModels.Permission permission = new SecurityModels.Permission();

            using (SqlConnection con = new SqlConnection(SecurityConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetPermission", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        permission.Id = Convert.ToInt32(reader["ID"].ToString());
                        permission.Name = reader["Name"].ToString();
                        permission.DisplayName = reader["DisplayName"].ToString();
                        permission.Active = id == 0 ? false : Convert.ToBoolean(reader["Active"].ToString());                       

                    }
                }
                con.Close();
            }
            return permission;
        }

        private List<SecurityModels.UserRole> GetUserRoles(string roles)
        {
            List<SecurityModels.UserRole> userRoles = new List<SecurityModels.UserRole>();
            List<string> lstRoles = roles.Split(',').ToList();

            foreach(string role in lstRoles)
            {
                userRoles.Add(
                    new SecurityModels.UserRole
                    {
                        Name = role.Substring(0, role.IndexOf(':')),
                        Assigned = role.Substring(role.IndexOf(':') + 1) == "1"
                    }
                    );
            }

            return userRoles;
        }

        private List<SecurityModels.RolePermission> GetRolePermissions(string permissions)
        {
            List<SecurityModels.RolePermission> rolePermissions = new List<SecurityModels.RolePermission>();
            List<string> lstPermisions = permissions.Split(',').ToList();

            foreach (string permision in lstPermisions)
            {
                rolePermissions.Add(
                    new SecurityModels.RolePermission
                    {
                        Name = permision.Substring(0, permision.IndexOf(':')),
                        Assigned = permision.Substring(permision.IndexOf(':') + 1) == "1"
                    }
                    );
            }

            return rolePermissions;
        }

        public SecurityModels.GetRolesResponse GetRoles(SecurityModels.GetListRequest getRolesRequest)
        {
            SecurityModels.GetRolesResponse getRolesResponse = new SecurityModels.GetRolesResponse();
            List<SecurityModels.Role> Roles = new List<SecurityModels.Role>();

            using (SqlConnection con = new SqlConnection(SecurityConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetRoles", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@SearchParm", SqlDbType.VarChar, 30).Value = getRolesRequest.SearchParm;
                    cmd.Parameters.Add("@PageSize", SqlDbType.Int, 0).Value = getRolesRequest.PageSize;
                    cmd.Parameters.Add("@PageNumber", SqlDbType.Int, 0).Value = getRolesRequest.PageNumber;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    int recordNumber = 1;

                    while (reader.Read())
                    {
                        if (recordNumber == 1)
                            getRolesResponse.RecordCount = Convert.ToInt32(reader["RecordCount"].ToString());

                        recordNumber++;

                        Roles.Add(new SecurityModels.Role
                        {
                            Id = Convert.ToInt32(reader["ID"].ToString()),
                            Name = reader["Name"].ToString(),
                            DisplayName = reader["DisplayName"].ToString(),
                            Active = Convert.ToBoolean(reader["Active"].ToString())
                        });
                    }
                    getRolesResponse.Roles = Roles;
                }
                con.Close();
            }
            return getRolesResponse;
        }

        public SecurityModels.GetPermissionsResponse GetPermissions(SecurityModels.GetListRequest getPermissionsRequest)
        {
            SecurityModels.GetPermissionsResponse getPermissionsResponse = new SecurityModels.GetPermissionsResponse();
            List<SecurityModels.Permission> Permissions = new List<SecurityModels.Permission>();

            using (SqlConnection con = new SqlConnection(SecurityConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetPermissions", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@SearchParm", SqlDbType.VarChar, 30).Value = getPermissionsRequest.SearchParm;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    int recordNumber = 1;

                    while (reader.Read())
                    {
                        if (recordNumber == 1)
                            getPermissionsResponse.RecordCount = Convert.ToInt32(reader["RecordCount"].ToString());

                        Permissions.Add(new SecurityModels.Permission
                        {
                            Id= Convert.ToInt32(reader["ID"].ToString()),
                            Name = reader["Name"].ToString(),
                            DisplayName = reader["DisplayName"].ToString(),
                            Active = Convert.ToBoolean(reader["Active"].ToString())
                        });
                    }
                    getPermissionsResponse.Permissions = Permissions;
                }
                con.Close();
            }
            return getPermissionsResponse;
        }

        public void UpdateUserRoles(SecurityModels.UpdateUserRolesRequest updateUserRolesRequest)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(SecurityConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateUserRoles", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = updateUserRolesRequest.ID;
                        cmd.Parameters.Add("@Roles", SqlDbType.VarChar).Value = updateUserRolesRequest.Roles;
                        con.Open();
                        cmd.ExecuteNonQuery();                        
                    }
                    con.Close();
                }
            }
            catch
            {
                throw;
            }            
        }

        public void UpdateUserStatus(SecurityModels.UpdateUserStatusRequest updateUserStatusRequest)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(SecurityConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateUserStatus", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = updateUserStatusRequest.ID;
                        cmd.Parameters.Add("@Active", SqlDbType.Bit).Value = updateUserStatusRequest.Active;
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            catch
            {
                throw;
            }
        }

        public int UpdateUserProfile(SecurityModels.User user)
        {
            DataTable tblRoles = new DataTable();
            tblRoles.Columns.Add("Role", typeof(string));
            tblRoles.Columns.Add("Assigned", typeof(bool));

            if (user.Roles != null)
            {              
                foreach (SecurityModels.UserRole userRole in user.Roles)
                {
                    if (userRole.Assigned)
                    {
                        DataRow row = tblRoles.NewRow();
                        row["Name"] = userRole.Name;
                        row["Assigned"] = userRole.Assigned;
                        tblRoles.Rows.Add(row);
                    }
                }
            }

            try
            {
                using (SqlConnection con = new SqlConnection(SecurityConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateUserProfile", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = user.Id;
                        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 20).Value = user.UserName;
                        cmd.Parameters.Add("@Password", SqlDbType.VarChar, 20).Value = user.Password;
                        cmd.Parameters.Add("@Active", SqlDbType.Bit).Value = user.Active? 1: 0;
                        cmd.Parameters.Add("@FirstName", SqlDbType.VarChar, 50).Value = user.FirstName;
                        cmd.Parameters.Add("@LastName", SqlDbType.VarChar, 50).Value = user.LastName;
                        cmd.Parameters.Add("@Email", SqlDbType.VarChar, 100).Value = user.Email;
                        cmd.Parameters.Add("@Roles", SqlDbType.Structured, 0).Value = tblRoles;
                        con.Open();
                        user.Id = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    con.Close();
                }
            }
            catch
            {
                throw;
            }

            return user.Id;
        }

        public int UpdateRole(SecurityModels.Role role)
        {
            DataTable tblPermissions = new DataTable();
            tblPermissions.Columns.Add("Name", typeof(string));
            tblPermissions.Columns.Add("Assigned", typeof(bool));

            if (role.Permissions != null)
            {
                foreach (SecurityModels.RolePermission permission in role.Permissions)
                {
                    if (permission.Assigned)
                    {
                        DataRow row = tblPermissions.NewRow();
                        row["Name"] = permission.Name;
                        row["Assigned"] = permission.Assigned;
                        tblPermissions.Rows.Add(row);
                    }
                }
            }

            try
            {
                using (SqlConnection con = new SqlConnection(SecurityConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateRole", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = role.Id;
                        cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = role.Name;
                        cmd.Parameters.Add("@DisplayName", SqlDbType.VarChar, 50).Value = role.DisplayName;
                        cmd.Parameters.Add("@Active", SqlDbType.Bit).Value = role.Active ? 1 : 0;
                        cmd.Parameters.Add("@Permissions", SqlDbType.Structured, 0).Value = tblPermissions;
                        con.Open();
                        role.Id = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    con.Close();
                }
            }
            catch
            {
                throw;
            }

            return role.Id;
        }

        public void UpdateRoleStatus(SecurityModels.Role role)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(SecurityConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateRoleStatus", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = role.Id;
                        cmd.Parameters.Add("@Active", SqlDbType.Bit).Value = role.Active;
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            catch
            {
                throw;
            }
        }

        public int UpdatePermission(SecurityModels.Permission permission)
        {            
            try
            {
                using (SqlConnection con = new SqlConnection(SecurityConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdatePermission", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = permission.Id;
                        cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = permission.Name;
                        cmd.Parameters.Add("@DisplayName", SqlDbType.VarChar, 50).Value = permission.DisplayName;
                        cmd.Parameters.Add("@Active", SqlDbType.Bit).Value = permission.Active ? 1 : 0;                      
                        con.Open();
                        permission.Id = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    con.Close();
                }
            }
            catch
            {
                throw;
            }

            return permission.Id;
        }

        public void UpdatePermissionStatus(SecurityModels.Permission permission)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(SecurityConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdatePermissionStatus", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = permission.Id;
                        cmd.Parameters.Add("@Active", SqlDbType.Bit).Value = permission.Active;
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            catch
            {
                throw;
            }
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }    
}